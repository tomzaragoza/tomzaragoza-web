(() => {
  "use strict";

  const SUMMARY_HASH = "#/summary";
  const DETAILS_HASH = "#/details;selectedAccount=V003";
  const CATEGORY_TITLE = "Credit Cards";
  const BALANCE_SELECTOR =
    "span.balance-amount, span.balance-amount--light";
  const REPLACEMENT_BALANCE = "$0";
  const SUMMARY_REPLACEMENTS = new Map([
    ["$19,989.00", "$0"]
  ]);
  const DETAILS_REPLACEMENTS = new Map([
    ["$14,372.58", "$0"],
    ["$297.00", "$0"],
    ["$1,127.42", "$15,500"]
  ]);
  const PAYMENT_OPTION_REPLACEMENTS = new Map([
    ["Minimum Payment $297.00", "Minimum Payment $0"],
    ["Last Statement Balance $14,372.58", "Last Statement Balance $0"],
    ["Current Balance $14,372.58", "Current Balance $0"]
  ]);
  const CREDIT_LINE_PATH =
    "/sgw5/SECOLBH/3m00/ISAMSecureRequest/v1/eBGRenderPage";
  const CREDIT_LINE_REPLACEMENTS = new Map([
    ["Credit Limit:", "$0"],
    ["Current Balance:", "$0"],
    ["Credit Available:", "$20,000"]
  ]);

  function isSummaryPage() {
    return window.location.hash.startsWith(SUMMARY_HASH);
  }

  function isDetailsPage() {
    return window.location.hash.startsWith(DETAILS_HASH);
  }

  function isCreditLinePage() {
    return window.location.pathname === CREDIT_LINE_PATH;
  }

  function normalizeText(value) {
    return value.replace(/\s+/g, " ").trim();
  }

  function replaceText(element, replacement) {
    if (normalizeText(element.textContent) === replacement) {
      return;
    }

    const textNodes = document.createTreeWalker(
      element,
      NodeFilter.SHOW_TEXT
    );

    let textNode = textNodes.nextNode();
    while (textNode && !normalizeText(textNode.nodeValue)) {
      textNode = textNodes.nextNode();
    }

    if (textNode) {
      textNode.nodeValue = replacement;
    }
  }

  function replaceCreditCardTotals() {
    if (!isSummaryPage()) {
      return;
    }

    for (const category of document.querySelectorAll(".category")) {
      const heading = category.querySelector(".account-header__title");

      if (!heading || normalizeText(heading.textContent) !== CATEGORY_TITLE) {
        continue;
      }

      for (const balance of category.querySelectorAll(BALANCE_SELECTOR)) {
        replaceText(balance, REPLACEMENT_BALANCE);
      }
    }

    for (const balance of document.querySelectorAll(BALANCE_SELECTOR)) {
      const replacement = SUMMARY_REPLACEMENTS.get(
        normalizeText(balance.textContent)
      );

      if (replacement) {
        replaceText(balance, replacement);
      }
    }
  }

  function replaceDetailsValues() {
    if (!isDetailsPage()) {
      return;
    }

    for (const detail of document.querySelectorAll("dd")) {
      const replacement = DETAILS_REPLACEMENTS.get(
        normalizeText(detail.textContent)
      );

      if (replacement) {
        replaceText(detail, replacement);
      }
    }

    for (const option of document.querySelectorAll("#amountDropdown option")) {
      const replacement = PAYMENT_OPTION_REPLACEMENTS.get(
        normalizeText(option.textContent)
      );

      if (replacement) {
        replaceText(option, replacement);
      }
    }
  }

  function replaceCreditLineValues() {
    if (!isCreditLinePage()) {
      return;
    }

    for (const row of document.querySelectorAll("table tr")) {
      const cells = row.querySelectorAll(":scope > td");

      if (cells.length < 2) {
        continue;
      }

      const replacement = CREDIT_LINE_REPLACEMENTS.get(
        normalizeText(cells[0].textContent)
      );

      if (!replacement) {
        continue;
      }

      replaceText(cells[1].querySelector("nobr") || cells[1], replacement);
    }

    for (const table of document.querySelectorAll("table")) {
      const header = table.querySelector("tr.dataTableHeaderRow");

      if (!header) {
        continue;
      }

      const headings = Array.from(header.querySelectorAll("td"), (cell) =>
        normalizeText(cell.textContent)
      );
      const paymentHeadings = [
        "Date",
        "Description",
        "Debits",
        "Credits",
        "Balance"
      ];

      if (!paymentHeadings.every((heading) => headings.includes(heading))) {
        continue;
      }

      table.classList.add("theext-empty-payments");

      for (const resultCount of table.querySelectorAll(
        'td.bodyText[colspan="5"]'
      )) {
        if (/^\d+ Results Found$/.test(normalizeText(resultCount.textContent))) {
          replaceText(resultCount, "0 Results Found");
        }
      }
    }
  }

  function updatePageState() {
    if (document.documentElement) {
      document.documentElement.classList.toggle(
        "theext-v003-details",
        isDetailsPage()
      );
      document.documentElement.classList.toggle(
        "theext-credit-line",
        isCreditLinePage()
      );
    }
  }

  function applyReplacements() {
    updatePageState();
    replaceCreditCardTotals();
    replaceDetailsValues();
    replaceCreditLineValues();
  }

  const observer = new MutationObserver(applyReplacements);

  observer.observe(document, {
    childList: true,
    characterData: true,
    subtree: true
  });

  window.addEventListener("hashchange", applyReplacements);
  applyReplacements();
})();
